## File Import Data Anggota

Folder ini menyimpan file-file temporer yang diupload saat mengimpor data.
File temporer tersebut akan dihapus setelah impor selesai.

Namun, karena beberapa hal seperti kegagalan sistem, interupsi user atau kejadian lain,
file-file mungkin saja tidak terhapus. Jadi, hapuslah file-file Excel dalam folder ini
untuk menjaga beberapa kemungkinan dan biarkan folder ini tetap kosong (hanya tersisa file ini).
